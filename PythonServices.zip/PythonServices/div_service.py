"""
DIVIDE WEB SERVICE - Port 5003
================================
Receives two numbers and returns their quotient
"""
from spyne import Application, rpc, ServiceBase, Double
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from wsgiref.simple_server import make_server

class DivService(ServiceBase):
    @rpc(Double, Double, _returns=Double)
    def divide(ctx, a, b):
        if b == 0:
            raise ValueError("Cannot divide by zero!")
        print(f"DivService: {a} / {b} = {a / b}")
        return a / b

application = Application(
    [DivService],
    tns='http://ode/bpel/divservice.wsdl',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

wsgi_app = WsgiApplication(application)

if __name__ == '__main__':
    server = make_server('0.0.0.0', 5003, wsgi_app)
    print("Divide Service running at http://localhost:5003")
    print("WSDL at http://localhost:5003/?wsdl")
    server.serve_forever()
