"""
ADD WEB SERVICE - Port 5000
============================
Receives two numbers and returns their sum
"""
from spyne import Application, rpc, ServiceBase, Double
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from wsgiref.simple_server import make_server

class AddService(ServiceBase):
    @rpc(Double, Double, _returns=Double)
    def add(ctx, a, b):
        print(f"AddService: {a} + {b} = {a + b}")
        return a + b

application = Application(
    [AddService],
    tns='http://ode/bpel/addservice.wsdl',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

wsgi_app = WsgiApplication(application)

if __name__ == '__main__':
    server = make_server('0.0.0.0', 5000, wsgi_app)
    print("Add Service running at http://localhost:5000")
    print("WSDL at http://localhost:5000/?wsdl")
    server.serve_forever()
