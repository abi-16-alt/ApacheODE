"""
SUBTRACT WEB SERVICE - Port 5001
==================================
Receives two numbers and returns their difference
"""
from spyne import Application, rpc, ServiceBase, Double
from spyne.protocol.soap import Soap11
from spyne.server.wsgi import WsgiApplication
from wsgiref.simple_server import make_server

class SubService(ServiceBase):
    @rpc(Double, Double, _returns=Double)
    def subtract(ctx, a, b):
        print(f"SubService: {a} - {b} = {a - b}")
        return a - b

application = Application(
    [SubService],
    tns='http://ode/bpel/subservice.wsdl',
    in_protocol=Soap11(validator='lxml'),
    out_protocol=Soap11()
)

wsgi_app = WsgiApplication(application)

if __name__ == '__main__':
    server = make_server('0.0.0.0', 5001, wsgi_app)
    print("Subtract Service running at http://localhost:5001")
    print("WSDL at http://localhost:5001/?wsdl")
    server.serve_forever()
